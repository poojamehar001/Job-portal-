<?php
$host="localhost";
$user="root";
$password="";
$dbname="jobportal";
$conn=mysqli_connect($host,$user,$password,$dbname);
if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
}
else {
    echo "Connected successfully";
}
$sql= "INSERT INTO contacts (name, email , message) VALUES ('$_POST[name]','$_POST[email]','$_POST[message]')";
if(mysqli_query($conn,$sql)){
    echo "New record created successfully";
}
else{
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);


?>