<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to bottom, #1a73e8, #004080);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
            animation: fadeIn 1.5s ease-in-out;
            backdrop-filter: blur(8px) saturate(140%);
            -webkit-backdrop-filter: blur(8px) saturate(140%);
            border: 1.5px solid #e3f0ff;
        }

        .login-container h1 {
            font-size: 32px;
            margin-bottom: 20px;
            color: #004080;
            font-weight: bold;
            background: linear-gradient(to right, #1a73e8, #ff6600);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .login-container input {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .login-container input:focus {
            border-color: #ff6600;
            box-shadow: 0 0 12px #ff66007a;
            outline: none;
        }

        .login-container input::placeholder {
            color: #b0b8c1;
            opacity: 1;
            font-size: 15px;
            letter-spacing: 0.5px;
        }

        .login-container button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(to right, #1a73e8, #004080);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .login-container button:hover {
            background: linear-gradient(to right, #004080, #1a73e8);
            transform: scale(1.05);
            box-shadow: 0 4px 18px rgba(26, 115, 232, 0.18);
        }

        .login-container p {
            margin-top: 20px;
            font-size: 14px;
        }

        .login-container a {
            color: #1a73e8;
            text-decoration: none;
        }

        .login-container a:hover {
            text-decoration: underline;
        }

        .login-container .icon {
            font-size: 48px;
            color: #1a73e8;
            margin-bottom: 10px;
            animation: float 2.5s infinite;
        }

        .login-container .divider {
            height: 1px;
            background: linear-gradient(to right, #1a73e8, #ff6600);
            border: none;
            margin: 24px 0 18px 0;
            opacity: 0.2;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0);}
            50% { transform: translateY(-8px);}
        }

        @media (max-width: 500px) {
            .login-container {
                padding: 24px 8px 18px 8px;
                max-width: 98vw;
            }
            .login-container h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="icon">🔒</div>
        <h1>Login</h1>
        <form action="process_login.php" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="divider"></div>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>
